import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertBookingSchema, type InsertBooking } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";

export default function Booking() {
  const { toast } = useToast();
  const [selectedDate, setSelectedDate] = useState<string>("");
  const [selectedTime, setSelectedTime] = useState<string>("");

  const form = useForm<InsertBooking>({
    resolver: zodResolver(insertBookingSchema),
    defaultValues: {
      name: "",
      email: "",
      company: "",
      goals: "",
      selectedDate: "",
      selectedTime: "",
    },
  });

  const bookingMutation = useMutation({
    mutationFn: async (data: InsertBooking) => {
      const response = await apiRequest("POST", "/api/bookings", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Consultation booked successfully!",
        description: "You'll receive a confirmation email shortly.",
      });
      form.reset();
      setSelectedDate("");
      setSelectedTime("");
    },
    onError: (error) => {
      toast({
        title: "Error booking consultation",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertBooking) => {
    if (!selectedDate || !selectedTime) {
      toast({
        title: "Please select date and time",
        description: "Both date and time must be selected to book your consultation.",
        variant: "destructive",
      });
      return;
    }

    bookingMutation.mutate({
      ...data,
      selectedDate,
      selectedTime,
    });
  };

  // Sample available times
  const availableTimes = ["9:00 AM", "10:30 AM", "2:00 PM", "3:30 PM", "5:00 PM"];
  
  // Sample calendar days (you would implement a proper calendar here)
  const calendarDays = ["15", "16", "17", "18", "19"];

  const selectDate = (date: string) => {
    setSelectedDate(date);
    form.setValue("selectedDate", date);
  };

  const selectTime = (time: string) => {
    setSelectedTime(time);
    form.setValue("selectedTime", time);
  };

  return (
    <div className="pt-16">
      <section className="section-padding bg-card">
        <div className="max-w-4xl mx-auto px-6">
          <div className="text-center mb-16">
            <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Book a Free Consultation</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Schedule a 30-minute strategy call to discuss your marketing goals and how I can help you achieve them.
            </p>
          </div>

          <Card className="bg-background border border-border">
            <CardContent className="p-8">
              <div className="grid md:grid-cols-2 gap-8">
                {/* Calendar/Time Selection */}
                <div>
                  <h3 className="text-xl font-semibold text-foreground mb-6">Select Date & Time</h3>
                  
                  {/* Date Selection */}
                  <div className="mb-6">
                    <label className="block text-sm font-medium text-foreground mb-3">Choose Date</label>
                    <div className="grid grid-cols-7 gap-2 text-center text-sm">
                      <div className="font-medium text-muted-foreground py-2">Mon</div>
                      <div className="font-medium text-muted-foreground py-2">Tue</div>
                      <div className="font-medium text-muted-foreground py-2">Wed</div>
                      <div className="font-medium text-muted-foreground py-2">Thu</div>
                      <div className="font-medium text-muted-foreground py-2">Fri</div>
                      <div className="font-medium text-muted-foreground py-2">Sat</div>
                      <div className="font-medium text-muted-foreground py-2">Sun</div>
                      
                      {calendarDays.map((day) => (
                        <button
                          key={day}
                          onClick={() => selectDate(`December ${day}, 2024`)}
                          className={cn(
                            "py-2 hover:bg-primary hover:text-primary-foreground rounded transition-colors",
                            selectedDate === `December ${day}, 2024` && "bg-primary text-primary-foreground"
                          )}
                          data-testid={`button-date-${day}`}
                        >
                          {day}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Time Selection */}
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-3">Available Times (PST)</label>
                    <div className="grid grid-cols-2 gap-2">
                      {availableTimes.map((time) => (
                        <button
                          key={time}
                          onClick={() => selectTime(time)}
                          className={cn(
                            "py-2 px-4 border border-border rounded hover:bg-primary hover:text-primary-foreground transition-colors",
                            selectedTime === time && "bg-primary text-primary-foreground"
                          )}
                          data-testid={`button-time-${time.replace(/[:\s]/g, '-')}`}
                        >
                          {time}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Booking Form */}
                <div>
                  <h3 className="text-xl font-semibold text-foreground mb-6">Your Information</h3>
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                      <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Full Name</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Your full name" 
                                data-testid="input-booking-name"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email</FormLabel>
                            <FormControl>
                              <Input 
                                type="email"
                                placeholder="your@email.com" 
                                data-testid="input-booking-email"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="company"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Company</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Company name (optional)" 
                                data-testid="input-booking-company"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="goals"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Marketing Goals</FormLabel>
                            <FormControl>
                              <Textarea
                                placeholder="What are your main marketing challenges?"
                                className="resize-none"
                                rows={3}
                                data-testid="textarea-booking-goals"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* Selected Date/Time Display */}
                      {(selectedDate && selectedTime) && (
                        <div className="bg-muted p-4 rounded-lg" data-testid="selected-appointment">
                          <div className="text-sm font-medium text-foreground mb-1">Selected Appointment:</div>
                          <div className="text-primary font-semibold">
                            {selectedDate} at {selectedTime} PST
                          </div>
                        </div>
                      )}

                      <Button 
                        type="submit" 
                        className="w-full"
                        disabled={bookingMutation.isPending || !selectedDate || !selectedTime}
                        data-testid="button-book-consultation"
                      >
                        {bookingMutation.isPending ? "Booking..." : "Book Free Consultation"}
                      </Button>
                    </form>
                  </Form>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}
